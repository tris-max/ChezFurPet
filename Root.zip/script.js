// script.js

// Function to show the welcome alert message
function showWelcomeMessage() {
    alert("Welcome pets of all ages, sizes and skills");
}
// Event listener for when the page is loaded
window.onload = showWelcomeMessage;
